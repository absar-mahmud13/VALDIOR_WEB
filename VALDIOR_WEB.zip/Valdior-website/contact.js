// Contact Page JavaScript Functionality

// Initialize contact page functionality
document.addEventListener('DOMContentLoaded', function() {
    setupFormValidation();
    setupFAQAccordion();
    setupFormSubmission();
    setupNewsletterForm();
    setupMessageOverlay();
    setupSocialTracking();
});

// Form validation
function setupFormValidation() {
    const form = document.getElementById('contact-form');
    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    
    inputs.forEach(input => {
        input.addEventListener('blur', validateField);
        input.addEventListener('input', clearFieldError);
    });
    
    // Phone number formatting
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        phoneInput.addEventListener('input', formatPhoneNumber);
    }
}

// Validate individual field
function validateField(e) {
    const field = e.target;
    const value = field.value.trim();
    
    // Remove existing error styling
    clearFieldError(e);
    
    // Check if required field is empty
    if (field.hasAttribute('required') && !value) {
        showFieldError(field, 'এই ক্ষেত্রটি পূরণ করা আবশ্যক');
        return false;
    }
    
    // Email validation
    if (field.type === 'email' && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            showFieldError(field, 'সঠিক ইমেইল ঠিকানা দিন');
            return false;
        }
    }
    
    // Phone validation (Bangladesh format)
    if (field.type === 'tel' && value) {
        const phoneRegex = /^(\+88)?01[3-9]\d{8}$/;
        if (!phoneRegex.test(value.replace(/\s+/g, ''))) {
            showFieldError(field, 'সঠিক ফোন নম্বর দিন (যেমন: 01712345678)');
            return false;
        }
    }
    
    return true;
}

// Show field error
function showFieldError(field, message) {
    field.style.borderColor = '#e74c3c';
    
    // Remove existing error message
    const existingError = field.parentNode.querySelector('.field-error');
    if (existingError) {
        existingError.remove();
    }
    
    // Add error message
    const errorElement = document.createElement('span');
    errorElement.className = 'field-error';
    errorElement.textContent = message;
    errorElement.style.cssText = `
        color: #e74c3c;
        font-size: 0.85rem;
        margin-top: 0.3rem;
        display: block;
    `;
    
    field.parentNode.appendChild(errorElement);
}

// Clear field error
function clearFieldError(e) {
    const field = e.target;
    field.style.borderColor = '#ddd';
    
    const errorElement = field.parentNode.querySelector('.field-error');
    if (errorElement) {
        errorElement.remove();
    }
}

// Format phone number
function formatPhoneNumber(e) {
    let value = e.target.value.replace(/\D/g, '');
    
    // Add +88 prefix if not present
    if (value.length > 0 && !value.startsWith('88')) {
        if (value.startsWith('01')) {
            value = '88' + value;
        }
    }
    
    // Format as +88 01XXX XXXXXX
    if (value.length >= 3) {
        if (value.startsWith('88')) {
            value = '+88 ' + value.substring(2);
        }
    }
    
    if (value.length > 7) {
        value = value.substring(0, 7) + ' ' + value.substring(7);
    }
    
    e.target.value = value;
}

// FAQ Accordion
function setupFAQAccordion() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Close all other FAQ items
            faqItems.forEach(otherItem => {
                otherItem.classList.remove('active');
            });
            
            // Toggle current item
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });
}

// Form submission
function setupFormSubmission() {
    const form = document.getElementById('contact-form');
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate all fields
        const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
        let isValid = true;
        
        inputs.forEach(input => {
            const event = { target: input };
            if (!validateField(event)) {
                isValid = false;
            }
        });
        
        if (!isValid) {
            showMessage('error', 'ত্রুটি!', 'অনুগ্রহ করে সকল ক্ষেত্র সঠিকভাবে পূরণ করুন।');
            return;
        }
        
        // Show loading state
        const submitBtn = form.querySelector('.submit-btn');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> পাঠানো হচ্ছে...';
        submitBtn.disabled = true;
        
        // Simulate form submission (in real app, this would be an API call)
        setTimeout(() => {
            // Reset form
            form.reset();
            
            // Reset button
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
            
            // Show success message
            showMessage('success', 'সফল!', 'আপনার বার্তা সফলভাবে পাঠানো হয়েছে। আমরা শীঘ্রই আপনার সাথে যোগাযোগ করব।');
            
            // Track form submission
            console.log('Contact form submitted successfully');
        }, 2000);
    });
}

// Newsletter form
function setupNewsletterForm() {
    const newsletterForm = document.getElementById('newsletter-form');
    
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const emailInput = this.querySelector('input[type="email"]');
        const email = emailInput.value.trim();
        
        if (!email) {
            showMessage('error', 'ত্রুটি!', 'অনুগ্রহ করে আপনার ইমেইল ঠিকানা দিন।');
            return;
        }
        
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            showMessage('error', 'ত্রুটি!', 'অনুগ্রহ করে সঠিক ইমেইল ঠিকানা দিন।');
            return;
        }
        
        // Show loading state
        const submitBtn = this.querySelector('button');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Subscribing...';
        submitBtn.disabled = true;
        
        // Simulate subscription (in real app, this would be an API call)
        setTimeout(() => {
            // Reset form
            emailInput.value = '';
            
            // Reset button
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
            
            // Show success message
            showMessage('success', 'সাবস্ক্রাইব সফল!', 'আপনি সফলভাবে আমাদের নিউজলেটার সাবস্ক্রাইব করেছেন।');
            
            // Track newsletter subscription
            console.log('Newsletter subscription successful');
        }, 1500);
    });
}

// Message overlay
function setupMessageOverlay() {
    const overlay = document.getElementById('message-overlay');
    const closeBtn = document.getElementById('message-close');
    
    closeBtn.addEventListener('click', () => {
        overlay.style.display = 'none';
        document.body.style.overflow = 'auto';
    });
    
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            overlay.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });
}

// Show message function
function showMessage(type, title, message) {
    const overlay = document.getElementById('message-overlay');
    const icon = document.getElementById('message-icon');
    const titleElement = document.getElementById('message-title');
    const messageElement = document.getElementById('message-text');
    
    // Set icon and styling based on type
    if (type === 'success') {
        icon.className = 'message-icon success';
        icon.innerHTML = '<i class="fas fa-check-circle"></i>';
    } else {
        icon.className = 'message-icon error';
        icon.innerHTML = '<i class="fas fa-exclamation-circle"></i>';
    }
    
    titleElement.textContent = title;
    messageElement.textContent = message;
    
    overlay.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    
    // Auto-close after 5 seconds
    setTimeout(() => {
        overlay.style.display = 'none';
        document.body.style.overflow = 'auto';
    }, 5000);
}

// Social media tracking
function setupSocialTracking() {
    const socialLinks = document.querySelectorAll('.social-link');
    
    socialLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            const platform = link.classList[1]; // facebook, instagram, etc.
            console.log(`Social media click: ${platform}`);
            
            // In a real application, you would open the actual social media link
            showMessage('info', 'সোশ্যাল মিডিয়া', `${platform} পেজ শীঘ্রই চালু হবে।`);
        });
    });
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Contact info click handlers
document.addEventListener('DOMContentLoaded', function() {
    // Phone number click to call
    const phoneLinks = document.querySelectorAll('a[href^="tel:"]');
    phoneLinks.forEach(link => {
        link.addEventListener('click', () => {
            console.log('Phone call initiated');
        });
    });
    
    // Email click to compose
    const emailLinks = document.querySelectorAll('a[href^="mailto:"]');
    emailLinks.forEach(link => {
        link.addEventListener('click', () => {
            console.log('Email composition initiated');
        });
    });
    
    // Directions button
    const directionsBtn = document.querySelector('.directions-btn');
    if (directionsBtn) {
        directionsBtn.addEventListener('click', () => {
            // In a real application, this would open Google Maps
            showMessage('info', 'দিকনির্দেশনা', 'Google Maps এ আমাদের অবস্থান দেখানো হবে।');
            console.log('Directions requested');
        });
    }
});

// Form field animations
function setupFieldAnimations() {
    const formFields = document.querySelectorAll('.form-group input, .form-group select, .form-group textarea');
    
    formFields.forEach(field => {
        field.addEventListener('focus', function() {
            this.parentNode.classList.add('focused');
        });
        
        field.addEventListener('blur', function() {
            if (!this.value) {
                this.parentNode.classList.remove('focused');
            }
        });
        
        // Check if field has value on load
        if (field.value) {
            field.parentNode.classList.add('focused');
        }
    });
}

// Initialize field animations
document.addEventListener('DOMContentLoaded', setupFieldAnimations);

// Page scroll animations
function setupScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    const animatedElements = document.querySelectorAll(`
        .contact-form-container,
        .contact-info-container,
        .map-section,
        .faq-section,
        .newsletter-section
    `);
    
    animatedElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(element);
    });
}

// Initialize scroll animations
document.addEventListener('DOMContentLoaded', setupScrollAnimations);

// Export functions for testing
window.contactPageFunctions = {
    validateField,
    formatPhoneNumber,
    showMessage,
    setupFormValidation,
    setupFAQAccordion
};
