// Shop Page JavaScript Functionality

// Global variables
let currentProducts = [];
let filteredProducts = [];
let currentView = 'grid';

// Initialize shop functionality
document.addEventListener('DOMContentLoaded', function() {
    initializeShop();
    setupEventListeners();
    loadProducts();
    handleURLSearch();
    setupCartView();
    setupOrderNow(); // Added for order now functionality
});

// Initialize shop features
function initializeShop() {
    // Set up price range slider
    const priceSlider = document.getElementById('priceRange');
    const currentPriceDisplay = document.getElementById('currentPrice');
    
    if (priceSlider && currentPriceDisplay) {
        priceSlider.addEventListener('input', function() {
            currentPriceDisplay.textContent = `৳${this.value}`;
            filterProducts();
        });
    }
    
    // Initialize view toggle
    const viewButtons = document.querySelectorAll('.view-btn');
    viewButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            viewButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            currentView = this.dataset.view;
            toggleView();
        });
    });
    
    // Initialize sort functionality
    const sortSelect = document.querySelector('.sort-select');
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            sortProducts(this.value);
        });
    }
}

// Setup event listeners
function setupEventListeners() {
    // Category filters
    const categoryFilters = document.querySelectorAll('input[type="checkbox"]');
    categoryFilters.forEach(filter => {
        filter.addEventListener('change', filterProducts);
    });
    
    // Size filters
    const sizeFilters = document.querySelectorAll('input[value="s"], input[value="m"], input[value="l"], input[value="xl"]');
    sizeFilters.forEach(filter => {
        filter.addEventListener('change', filterProducts);
    });
    
    // Color filters
    const colorOptions = document.querySelectorAll('.color-option');
    colorOptions.forEach(option => {
        option.addEventListener('click', function() {
            this.classList.toggle('active');
            filterProducts();
        });
    });
    
    // Clear filters
    const clearFiltersBtn = document.querySelector('.clear-filters');
    if (clearFiltersBtn) {
        clearFiltersBtn.addEventListener('click', clearAllFilters);
    }
    
    // Quick view buttons
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('quick-view-btn')) {
            e.preventDefault();
            const productCard = e.target.closest('.product-card');
            openQuickView(productCard);
        }
        
        if (e.target.classList.contains('wishlist-btn') || e.target.parentElement.classList.contains('wishlist-btn')) {
            e.preventDefault();
            const productCard = e.target.closest('.product-card');
            toggleWishlist(productCard);
        }
        
        if (e.target.classList.contains('add-to-cart-btn')) {
            e.preventDefault();
            const productCard = e.target.closest('.product-card');
            if (productCard) {
                addToCart(productCard);
            } else {
                // Handle modal add to cart
                const modal = document.getElementById('quick-view-modal');
                if (modal && modal.style.display === 'flex') {
                    const modalTitle = document.getElementById('modal-title').textContent;
                    const modalPrice = document.getElementById('modal-price').textContent;
                    
                    // Create a temporary product object for modal
                    const tempProduct = {
                        querySelector: (selector) => {
                            if (selector === '.product-title') return { textContent: modalTitle };
                            if (selector === '.current-price') return { textContent: modalPrice };
                            return null;
                        }
                    };
                    addToCart(tempProduct);
                }
            }
        }
    });
    
    // Modal functionality
    const modal = document.getElementById('quick-view-modal');
    const modalClose = document.querySelector('.modal-close');
    
    if (modalClose) {
        modalClose.addEventListener('click', closeQuickView);
    }
    
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeQuickView();
            }
        });
    }
    
    // Quantity controls in modal
    const qtyMinus = document.querySelector('.qty-btn.minus');
    const qtyPlus = document.querySelector('.qty-btn.plus');
    const qtyInput = document.getElementById('quantity-input');
    
    if (qtyMinus) {
        qtyMinus.addEventListener('click', function() {
            const currentValue = parseInt(qtyInput.value);
            if (currentValue > 1) {
                qtyInput.value = currentValue - 1;
            }
        });
    }
    
    if (qtyPlus) {
        qtyPlus.addEventListener('click', function() {
            const currentValue = parseInt(qtyInput.value);
            qtyInput.value = currentValue + 1;
        });
    }
    
    // Mobile filter toggle
    const mobileFilterToggle = document.querySelector('.mobile-filter-toggle');
    const sidebar = document.querySelector('.shop-sidebar');
    
    if (mobileFilterToggle) {
        mobileFilterToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
    
    // Pagination
    const pageButtons = document.querySelectorAll('.page-btn');
    pageButtons.forEach(btn => {
        if (!btn.classList.contains('prev') && !btn.classList.contains('next')) {
            btn.addEventListener('click', function() {
                pageButtons.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                // In a real application, this would load the corresponding page
                scrollToTop();
            });
        }
    });
}

// Load products (in a real app, this would fetch from an API)
function loadProducts() {
    currentProducts = Array.from(document.querySelectorAll('.product-card'));
    filteredProducts = [...currentProducts];
    updateResultsCount();
}

// Filter products based on selected criteria
function filterProducts() {
    const selectedCategories = getSelectedCategories();
    const selectedSizes = getSelectedSizes();
    const selectedColors = getSelectedColors();
    const maxPrice = parseInt(document.getElementById('priceRange').value);
    
    filteredProducts = currentProducts.filter(product => {
        // Category filter
        const productCategory = product.dataset.category;
        const categoryMatch = selectedCategories.length === 0 || 
                             selectedCategories.includes('all') || 
                             selectedCategories.includes(productCategory);
        
        // Size filter
        const productSizes = product.dataset.size.split(',');
        const sizeMatch = selectedSizes.length === 0 || 
                         selectedSizes.some(size => productSizes.includes(size));
        
        // Color filter
        const productColor = product.dataset.color;
        const colorMatch = selectedColors.length === 0 || 
                          selectedColors.includes(productColor);
        
        // Price filter
        const productPrice = parseInt(product.dataset.price);
        const priceMatch = productPrice <= maxPrice;
        
        return categoryMatch && sizeMatch && colorMatch && priceMatch;
    });
    
    displayFilteredProducts();
    updateResultsCount();
}

// Get selected categories
function getSelectedCategories() {
    const categoryInputs = document.querySelectorAll('input[value="all"], input[value="shirts"], input[value="pants"], input[value="suits"], input[value="casual"], input[value="panjabi"]');
    const selected = [];
    
    categoryInputs.forEach(input => {
        if (input.checked) {
            selected.push(input.value);
        }
    });
    
    return selected;
}

// Get selected sizes
function getSelectedSizes() {
    const sizeInputs = document.querySelectorAll('input[value="s"], input[value="m"], input[value="l"], input[value="xl"]');
    const selected = [];
    
    sizeInputs.forEach(input => {
        if (input.checked) {
            selected.push(input.value);
        }
    });
    
    return selected;
}

// Get selected colors
function getSelectedColors() {
    const colorOptions = document.querySelectorAll('.color-option.active');
    const selected = [];
    
    colorOptions.forEach(option => {
        selected.push(option.dataset.color);
    });
    
    return selected;
}

// Display filtered products
function displayFilteredProducts() {
    const productsGrid = document.getElementById('products-grid');
    
    // Hide all products
    currentProducts.forEach(product => {
        product.style.display = 'none';
    });
    
    // Show filtered products
    filteredProducts.forEach(product => {
        product.style.display = currentView === 'list' ? 'flex' : 'block';
    });
}

// Sort products
function sortProducts(sortBy) {
    const productsGrid = document.getElementById('products-grid');
    
    switch (sortBy) {
        case 'price-low':
            filteredProducts.sort((a, b) => parseInt(a.dataset.price) - parseInt(b.dataset.price));
            break;
        case 'price-high':
            filteredProducts.sort((a, b) => parseInt(b.dataset.price) - parseInt(a.dataset.price));
            break;
        case 'name':
            filteredProducts.sort((a, b) => {
                const nameA = a.querySelector('.product-title').textContent;
                const nameB = b.querySelector('.product-title').textContent;
                return nameA.localeCompare(nameB);
            });
            break;
        case 'newest':
            // In a real app, this would sort by date
            filteredProducts.reverse();
            break;
        default:
            // Default sorting
            break;
    }
    
    // Re-append products in sorted order
    filteredProducts.forEach(product => {
        productsGrid.appendChild(product);
    });
}

// Toggle between grid and list view
function toggleView() {
    const productsGrid = document.getElementById('products-grid');
    
    if (currentView === 'list') {
        productsGrid.classList.add('list-view');
    } else {
        productsGrid.classList.remove('list-view');
    }
    
    displayFilteredProducts();
}

// Clear all filters
function clearAllFilters() {
    // Clear category filters
    const categoryInputs = document.querySelectorAll('input[type="checkbox"]');
    categoryInputs.forEach(input => {
        input.checked = input.value === 'all';
    });
    
    // Clear color filters
    const colorOptions = document.querySelectorAll('.color-option');
    colorOptions.forEach(option => {
        option.classList.remove('active');
    });
    
    // Reset price slider
    const priceSlider = document.getElementById('priceRange');
    const currentPriceDisplay = document.getElementById('currentPrice');
    if (priceSlider && currentPriceDisplay) {
        priceSlider.value = 2500;
        currentPriceDisplay.textContent = '৳2500';
    }
    
    // Refilter products
    filterProducts();
}

// Update results count
function updateResultsCount() {
    const resultsCount = document.getElementById('results-count');
    if (resultsCount) {
        resultsCount.textContent = filteredProducts.length;
    }
}

// Quick view functionality
function openQuickView(productCard) {
    const modal = document.getElementById('quick-view-modal');
    const title = productCard.querySelector('.product-title').textContent;
    const description = productCard.querySelector('.product-description').textContent;
    const price = productCard.querySelector('.current-price').textContent;
    
    // Update modal content
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-description').textContent = description;
    document.getElementById('modal-price').textContent = price;
    
    // Show modal
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeQuickView() {
    const modal = document.getElementById('quick-view-modal');
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Wishlist functionality
function toggleWishlist(productCard) {
    const wishlistBtn = productCard.querySelector('.wishlist-btn i');
    
    if (wishlistBtn.classList.contains('far')) {
        wishlistBtn.classList.remove('far');
        wishlistBtn.classList.add('fas');
        wishlistBtn.style.color = '#e74c3c';
        
        // Increment wishlist counter
        wishlistCount++;
        updateWishlistCounter();
        saveToLocalStorage('wishlistCount', wishlistCount);
        
        // Show notification
        showNotification('Added to wishlist!', 'success');
    } else {
        wishlistBtn.classList.remove('fas');
        wishlistBtn.classList.add('far');
        wishlistBtn.style.color = '';
        
        // Decrement wishlist counter
        wishlistCount = Math.max(0, wishlistCount - 1);
        updateWishlistCounter();
        saveToLocalStorage('wishlistCount', wishlistCount);
        
        showNotification('Removed from wishlist!', 'info');
    }
}

// Add to cart functionality
function addToCart(productCard) {
    if (!productCard) {
        console.error('Product card not found');
        return;
    }
    
    const titleElement = productCard.querySelector('.product-title');
    const priceElement = productCard.querySelector('.current-price');
    
    if (!titleElement || !priceElement) {
        console.error('Product title or price not found');
        return;
    }
    
    const title = titleElement.textContent;
    const price = priceElement.textContent;
    
    // Check if in modal
    const modal = document.getElementById('quick-view-modal');
    const isInModal = modal && modal.style.display === 'flex';
    
    let selectedSize = 'M'; // default
    let quantity = 1;
    let paymentMethod = 'cod';
    
    if (isInModal) {
        // Get selected options from modal
        const sizeSelect = document.getElementById('size-select');
        const quantityInput = document.getElementById('quantity-input');
        const selectedPayment = document.querySelector('input[name="payment"]:checked');
        
        selectedSize = sizeSelect ? sizeSelect.value : 'M';
        quantity = quantityInput ? parseInt(quantityInput.value) : 1;
        paymentMethod = selectedPayment ? selectedPayment.value : 'cod';
        
        // Close modal
        closeQuickView();
    }
    
    // Create cart item
    const cartItem = {
        title: title,
        price: price,
        size: selectedSize,
        quantity: quantity,
        paymentMethod: paymentMethod,
        timestamp: Date.now()
    };
    
    // Save to local storage
    let cartItems = getFromLocalStorage('cartItems') || [];
    cartItems.push(cartItem);
    saveToLocalStorage('cartItems', cartItems);
    
    // Increment cart counter
    cartCount += quantity;
    updateCartCounter();
    saveToLocalStorage('cartCount', cartCount);
    
    // Show notification with payment method
    const paymentText = getPaymentMethodText(paymentMethod);
    console.log('Item added to cart:', { title, price, size: selectedSize, quantity, paymentMethod });
    showNotification(`${title} কার্টে যোগ করা হয়েছে! (${paymentText})`, 'success');
    
    // Add animation effect
    const btn = productCard ? productCard.querySelector('.add-to-cart-btn') : 
                document.querySelector('.add-to-cart-btn.large');
    if (btn) {
        btn.style.background = '#27ae60';
        btn.textContent = 'Added!';
        
        setTimeout(() => {
            btn.style.background = '';
            btn.textContent = 'Add to Cart';
        }, 1500);
    }
}

// Get payment method display text
function getPaymentMethodText(method) {
    const methods = {
        'cod': 'Cash on Delivery',
        'bkash': 'বিকাশ',
        'nagad': 'নগদ',
        'rocket': 'রকেট',
        'card': 'Card Payment',
        'bank': 'Bank Transfer'
    };
    return methods[method] || 'Cash on Delivery';
}

// Order Now Functionality
function setupOrderNow() {
    const orderButtons = document.querySelectorAll('.order-now-btn');
    
    // Add event listeners to all order now buttons
    orderButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const productCard = this.closest('.product-card');
            if (productCard) {
                redirectToOrderPage(productCard);
            }
        });
    });
}

function redirectToOrderPage(productCard) {
    const productImg = productCard.querySelector('.product-img');
    const productTitle = productCard.querySelector('.product-title');
    const productPrice = productCard.querySelector('.current-price');
    const productOriginalPrice = productCard.querySelector('.original-price');
    const productDescription = productCard.querySelector('.product-description');
    
    if (!productTitle || !productPrice) {
        showNotification('পণ্যের তথ্য পাওয়া যায়নি', 'error');
        return;
    }
    
    // Get selected size and quantity (if in modal)
    let selectedSize = 'M';
    let selectedQuantity = 1;
    
    const quickViewModal = document.getElementById('quick-view-modal');
    const isInModal = quickViewModal && quickViewModal.style.display === 'flex';
    if (isInModal) {
        const sizeSelector = document.querySelector('input[name="size"]:checked');
        const quantityInput = document.getElementById('quantity-input');
        selectedSize = sizeSelector ? sizeSelector.value.toUpperCase() : 'M';
        selectedQuantity = quantityInput ? parseInt(quantityInput.value) : 1;
        
        // Close quick view modal
        closeQuickView();
    }
    
    // Extract price
    const priceText = productPrice.textContent.replace('৳', '').replace(',', '');
    const price = parseInt(priceText);
    
    // Extract original price if exists
    let originalPrice = null;
    if (productOriginalPrice && productOriginalPrice.textContent) {
        const originalPriceText = productOriginalPrice.textContent.replace('৳', '').replace(',', '');
        originalPrice = parseInt(originalPriceText);
    }
    
    // Create product data object
    const productData = {
        name: productTitle.textContent,
        price: price,
        originalPrice: originalPrice,
        image: productImg ? productImg.src : '',
        description: productDescription ? productDescription.textContent : '',
        selectedSize: selectedSize,
        quantity: selectedQuantity,
        sizes: ['s', 'm', 'l', 'xl'] // Default available sizes
    };
    
    // Redirect to order page with product data
    const productDataParam = encodeURIComponent(JSON.stringify(productData));
    window.location.href = `order.html?product=${productDataParam}`;
}

function showOrderModal(productCard) {
    const orderModal = document.getElementById('order-modal');
    const productImg = productCard.querySelector('.product-img');
    const productTitle = productCard.querySelector('.product-title');
    const productPrice = productCard.querySelector('.current-price');
    
    if (!orderModal || !productTitle || !productPrice) return;
    
    // Get selected size and quantity (if in modal)
    let selectedSize = 'M';
    let selectedQuantity = 1;
    
    const quickViewModal = document.getElementById('quick-view-modal');
    const isInModal = quickViewModal && quickViewModal.style.display === 'flex';
    if (isInModal) {
        const sizeSelector = document.querySelector('input[name="size"]:checked');
        const quantityInput = document.getElementById('quantity-input');
        selectedSize = sizeSelector ? sizeSelector.value.toUpperCase() : 'M';
        selectedQuantity = quantityInput ? parseInt(quantityInput.value) : 1;
    }
    
    // Fill order modal with product info
    const orderProductImg = document.getElementById('order-product-image');
    const orderProductName = document.getElementById('order-product-name');
    const orderProductPrice = document.getElementById('order-product-price');
    const orderProductSize = document.getElementById('order-product-size');
    const orderProductQuantity = document.getElementById('order-product-quantity');
    
    if (orderProductImg && productImg) {
        orderProductImg.src = productImg.src;
        orderProductImg.alt = productTitle.textContent;
    }
    
    if (orderProductName) orderProductName.textContent = productTitle.textContent;
    if (orderProductPrice) orderProductPrice.textContent = productPrice.textContent;
    if (orderProductSize) orderProductSize.textContent = `সাইজ: ${selectedSize}`;
    if (orderProductQuantity) orderProductQuantity.textContent = `পরিমাণ: ${selectedQuantity}`;
    
    // Calculate totals
    const priceText = productPrice.textContent.replace('৳', '').replace(',', '');
    const price = parseInt(priceText);
    const subtotal = price * selectedQuantity;
    const deliveryCharge = 120;
    const total = subtotal + deliveryCharge;
    
    const subtotalElement = document.getElementById('order-subtotal');
    const totalElement = document.getElementById('order-total');
    if (subtotalElement) subtotalElement.textContent = `৳${subtotal.toLocaleString()}`;
    if (totalElement) totalElement.textContent = `৳${total.toLocaleString()}`;
    
    // Store product info for order processing
    orderModal.dataset.productInfo = JSON.stringify({
        name: productTitle.textContent,
        price: price,
        size: selectedSize,
        quantity: selectedQuantity,
        subtotal: subtotal,
        total: total,
        image: productImg ? productImg.src : ''
    });
    
    // Show modal
    orderModal.style.display = 'flex';
    
    // Close quick view if open
    if (isInModal) {
        closeQuickView();
    }
}

function handleOrderSubmission(e) {
    e.preventDefault();
    
    const orderModal = document.getElementById('order-modal');
    const productInfo = JSON.parse(orderModal.dataset.productInfo || '{}');
    
    // Get form data
    const formData = new FormData(e.target);
    const orderData = {
        // Product info
        product: productInfo,
        
        // Customer info
        customerName: formData.get('customerName'),
        customerPhone: formData.get('customerPhone'),
        customerEmail: formData.get('customerEmail'),
        
        // Delivery info
        deliveryAddress: formData.get('deliveryAddress'),
        deliveryArea: formData.get('deliveryArea'),
        
        // Additional info
        specialInstructions: formData.get('specialInstructions'),
        
        // Order details
        orderDate: new Date().toISOString(),
        orderId: generateOrderId(),
        status: 'pending'
    };
    
    // Validate required fields
    if (!orderData.customerName || !orderData.customerPhone || !orderData.deliveryAddress || !orderData.deliveryArea) {
        showNotification('দয়া করে সব প্রয়োজনীয় তথ্য পূরণ করুন!', 'error');
        return;
    }
    
    // Save order to localStorage
    saveOrder(orderData);
    
    // Show success message
    showNotification(`অর্ডার সফলভাবে সম্পন্ন হয়েছে! অর্ডার নম্বর: ${orderData.orderId}`, 'success');
    
    // Close modal and reset form
    orderModal.style.display = 'none';
    e.target.reset();
    
    console.log('Order placed:', orderData);
}

function generateOrderId() {
    const now = new Date();
    const timestamp = now.getTime().toString().slice(-8);
    const random = Math.floor(Math.random() * 100).toString().padStart(2, '0');
    return `VLD${timestamp}${random}`;
}

function saveOrder(orderData) {
    const orders = getFromLocalStorage('orders') || [];
    orders.push(orderData);
    saveToLocalStorage('orders', orders);
}

// Function to get all orders (for admin panel or order management)
function getAllOrders() {
    return getFromLocalStorage('orders') || [];
}

// Function to update order status
function updateOrderStatus(orderId, newStatus) {
    const orders = getAllOrders();
    const orderIndex = orders.findIndex(order => order.orderId === orderId);
    if (orderIndex !== -1) {
        orders[orderIndex].status = newStatus;
        orders[orderIndex].updatedAt = new Date().toISOString();
        saveToLocalStorage('orders', orders);
        return true;
    }
    return false;
}

// Show notification
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Style the notification
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 5px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        z-index: 2000;
        transform: translateX(100%);
        transition: transform 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Scroll to top
function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

// Search functionality specific to shop page
function searchProducts(searchTerm) {
    if (!searchTerm.trim()) {
        filteredProducts = [...currentProducts];
        displayFilteredProducts();
        updateResultsCount();
        return;
    }
    
    filteredProducts = currentProducts.filter(product => {
        const title = product.querySelector('.product-title').textContent.toLowerCase();
        const description = product.querySelector('.product-description').textContent.toLowerCase();
        const category = product.dataset.category.toLowerCase();
        
        return title.includes(searchTerm.toLowerCase()) ||
               description.includes(searchTerm.toLowerCase()) ||
               category.includes(searchTerm.toLowerCase());
    });
    
    displayFilteredProducts();
    updateResultsCount();
}

// Override the global search functionality for shop page
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.querySelector('.search-input');
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const searchTerm = this.value.trim();
                if (searchTerm) {
                    searchProducts(searchTerm);
                    // Close search overlay
                    const searchOverlay = document.getElementById('search-overlay');
                    searchOverlay.style.display = 'none';
                    document.body.style.overflow = 'auto';
                }
            }
        });
    }
});

// Mobile responsive adjustments
function handleMobileView() {
    const isMobile = window.innerWidth <= 768;
    const sidebar = document.querySelector('.shop-sidebar');
    
    if (isMobile && !document.querySelector('.mobile-filter-toggle')) {
        // Add mobile filter toggle button
        const toggleBtn = document.createElement('button');
        toggleBtn.className = 'mobile-filter-toggle';
        toggleBtn.innerHTML = '<i class="fas fa-filter"></i> Filters';
        
        const productsArea = document.querySelector('.products-area');
        productsArea.parentNode.insertBefore(toggleBtn, productsArea);
        
        // Add event listener
        toggleBtn.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
}

// Handle window resize
window.addEventListener('resize', handleMobileView);

// Initialize mobile view on load
document.addEventListener('DOMContentLoaded', handleMobileView);

// Setup cart view functionality
function setupCartView() {
    const cartIcon = document.getElementById('cart-icon');
    
    if (cartIcon) {
        cartIcon.addEventListener('click', showCartModal);
    }
}

// Show cart modal
function showCartModal() {
    const cartItems = getFromLocalStorage('cartItems') || [];
    
    if (cartItems.length === 0) {
        showNotification('আপনার কার্ট খালি!', 'info');
        return;
    }
    
    // Create cart modal
    const modal = document.createElement('div');
    modal.className = 'cart-modal-overlay';
    modal.innerHTML = `
        <div class="cart-modal-content">
            <div class="cart-modal-header">
                <h3>আপনার কার্ট (${cartItems.length} আইটেম)</h3>
                <button class="cart-modal-close">&times;</button>
            </div>
            <div class="cart-modal-body">
                ${cartItems.map(item => `
                    <div class="cart-item">
                        <div class="cart-item-info">
                            <h4>${item.title}</h4>
                            <p>সাইজ: ${item.size} | পরিমাণ: ${item.quantity}</p>
                            <p>পেমেন্ট: ${getPaymentMethodText(item.paymentMethod)}</p>
                        </div>
                        <div class="cart-item-price">
                            <span>${item.price}</span>
                            <button class="remove-cart-item" data-timestamp="${item.timestamp}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
            <div class="cart-modal-footer">
                <button class="clear-cart-btn">কার্ট খালি করুন</button>
                <button class="checkout-btn">অর্ডার করুন</button>
            </div>
        </div>
    `;
    
    // Add styles
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 2000;
    `;
    
    document.body.appendChild(modal);
    document.body.style.overflow = 'hidden';
    
    // Add event listeners
    modal.querySelector('.cart-modal-close').addEventListener('click', closeCartModal);
    modal.querySelector('.clear-cart-btn').addEventListener('click', clearCart);
    modal.querySelector('.checkout-btn').addEventListener('click', processCheckout);
    
    // Remove item functionality
    modal.querySelectorAll('.remove-cart-item').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const timestamp = e.target.closest('.remove-cart-item').dataset.timestamp;
            removeCartItem(timestamp);
            closeCartModal();
            showCartModal(); // Refresh modal
        });
    });
    
    // Close on outside click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeCartModal();
        }
    });
}

// Close cart modal
function closeCartModal() {
    const modal = document.querySelector('.cart-modal-overlay');
    if (modal) {
        document.body.removeChild(modal);
        document.body.style.overflow = 'auto';
    }
}

// Remove cart item
function removeCartItem(timestamp) {
    let cartItems = getFromLocalStorage('cartItems') || [];
    const itemIndex = cartItems.findIndex(item => item.timestamp == timestamp);
    
    if (itemIndex > -1) {
        const removedItem = cartItems[itemIndex];
        cartItems.splice(itemIndex, 1);
        
        // Update cart count
        cartCount -= removedItem.quantity;
        updateCartCounter();
        
        // Save to storage
        saveToLocalStorage('cartItems', cartItems);
        saveToLocalStorage('cartCount', cartCount);
        
        showNotification('আইটেম কার্ট থেকে সরানো হয়েছে', 'info');
    }
}

// Clear entire cart
function clearCart() {
    if (confirm('আপনি কি সব আইটেম কার্ট থেকে সরাতে চান?')) {
        saveToLocalStorage('cartItems', []);
        cartCount = 0;
        updateCartCounter();
        saveToLocalStorage('cartCount', cartCount);
        
        closeCartModal();
        showNotification('কার্ট খালি করা হয়েছে', 'info');
    }
}

// Process checkout
function processCheckout() {
    const cartItems = getFromLocalStorage('cartItems') || [];
    
    if (cartItems.length === 0) {
        showNotification('আপনার কার্ট খালি!', 'error');
        return;
    }
    
    // Group by payment method
    const paymentGroups = {};
    cartItems.forEach(item => {
        if (!paymentGroups[item.paymentMethod]) {
            paymentGroups[item.paymentMethod] = [];
        }
        paymentGroups[item.paymentMethod].push(item);
    });
    
    let orderSummary = 'অর্ডার সামারি:\n\n';
    Object.keys(paymentGroups).forEach(method => {
        orderSummary += `${getPaymentMethodText(method)}:\n`;
        paymentGroups[method].forEach(item => {
            orderSummary += `- ${item.title} (${item.size}) x${item.quantity}\n`;
        });
        orderSummary += '\n';
    });
    
    orderSummary += 'আমরা শীঘ্রই আপনার সাথে যোগাযোগ করব।';
    
    alert(orderSummary);
    
    // Clear cart after order
    clearCart();
    closeCartModal();
    
    showNotification('অর্ডার সফল! আমরা শীঘ্রই যোগাযোগ করব।', 'success');
}

// Handle URL search parameter
function handleURLSearch() {
    const urlParams = new URLSearchParams(window.location.search);
    const searchTerm = urlParams.get('search');
    
    if (searchTerm) {
        // Update search input if visible
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.value = searchTerm;
        }
        
        // Perform search
        searchProducts(searchTerm);
        
        // Show search notification
        showNotification(`Searching for: "${searchTerm}"`, 'info');
        
        // Clear URL parameter
        window.history.replaceState({}, document.title, window.location.pathname);
    }
}
