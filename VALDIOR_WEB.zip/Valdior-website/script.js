// Mobile Navigation Toggle
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('nav-menu');

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-link').forEach(n => n.addEventListener('click', () => {
    hamburger.classList.remove('active');
    navMenu.classList.remove('active');
}));

// Search Overlay
const searchIcon = document.getElementById('search-icon');
const searchOverlay = document.getElementById('search-overlay');
const closeSearch = document.getElementById('close-search');

searchIcon.addEventListener('click', () => {
    searchOverlay.style.display = 'flex';
    document.body.style.overflow = 'hidden';
});

closeSearch.addEventListener('click', () => {
    searchOverlay.style.display = 'none';
    document.body.style.overflow = 'auto';
});

// Close search overlay when clicking outside
searchOverlay.addEventListener('click', (e) => {
    if (e.target === searchOverlay) {
        searchOverlay.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
});

// Smooth scrolling for CTA button
document.querySelector('.cta-button').addEventListener('click', () => {
    document.querySelector('.featured-collections').scrollIntoView({
        behavior: 'smooth'
    });
});

// Collection buttons navigation
document.querySelectorAll('.collection-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        // In a real application, this would navigate to the shop page with filters
        window.location.href = 'shop.html';
    });
});

// Offer button navigation
document.querySelector('.offer-btn').addEventListener('click', () => {
    window.location.href = 'shop.html';
});

// Navbar scroll effect
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 100) {
        navbar.style.background = 'rgba(255, 255, 255, 0.98)';
    } else {
        navbar.style.background = 'rgba(255, 255, 255, 0.95)';
    }
});

// Cart and Wishlist counters (placeholder functionality)
let cartCount = 0;
let wishlistCount = 0;

// Shopping cart functionality (basic)
const cartIcon = document.getElementById('cart-icon');
const wishlistIcon = document.getElementById('wishlist-icon');

// Add cart counter
function updateCartCounter() {
    let counter = document.querySelector('.cart-counter');
    if (!counter && cartCount > 0) {
        counter = document.createElement('span');
        counter.className = 'cart-counter';
        counter.style.cssText = `
            position: absolute;
            top: -8px;
            right: -8px;
            background: #d4af37;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        `;
        cartIcon.style.position = 'relative';
        cartIcon.appendChild(counter);
    }
    if (counter) {
        counter.textContent = cartCount;
        counter.style.display = cartCount > 0 ? 'flex' : 'none';
    }
}

// Add wishlist counter
function updateWishlistCounter() {
    let counter = document.querySelector('.wishlist-counter');
    if (!counter && wishlistCount > 0) {
        counter = document.createElement('span');
        counter.className = 'wishlist-counter';
        counter.style.cssText = `
            position: absolute;
            top: -8px;
            right: -8px;
            background: #e74c3c;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        `;
        wishlistIcon.style.position = 'relative';
        wishlistIcon.appendChild(counter);
    }
    if (counter) {
        counter.textContent = wishlistCount;
        counter.style.display = wishlistCount > 0 ? 'flex' : 'none';
    }
}

// Initialize counters
updateCartCounter();
updateWishlistCounter();

// Animation on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe elements for animation
document.querySelectorAll('.collection-card, .testimonial-card, .story-content').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
});

// Search functionality
const searchInput = document.querySelector('.search-input');
if (searchInput) {
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const searchTerm = searchInput.value.trim();
            if (searchTerm) {
                // Check if we're on shop page
                if (window.location.pathname.includes('shop.html')) {
                    // Use shop page search function if available
                    if (typeof searchProducts === 'function') {
                        searchProducts(searchTerm);
                    }
                } else {
                    // Redirect to shop page with search
                    window.location.href = `shop.html?search=${encodeURIComponent(searchTerm)}`;
                }
                
                // Close search overlay
                searchOverlay.style.display = 'none';
                document.body.style.overflow = 'auto';
                searchInput.value = '';
            }
        }
    });

    // Add search button functionality
    const searchButton = document.createElement('button');
    searchButton.innerHTML = '<i class="fas fa-search"></i>';
    searchButton.className = 'search-btn';
    searchButton.style.cssText = `
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        background: #d4af37;
        color: white;
        border: none;
        padding: 8px 12px;
        border-radius: 5px;
        cursor: pointer;
    `;
    
    const searchContainer = document.querySelector('.search-container');
    if (searchContainer) {
        searchContainer.style.position = 'relative';
        searchContainer.appendChild(searchButton);
        
        searchButton.addEventListener('click', () => {
            const searchTerm = searchInput.value.trim();
            if (searchTerm) {
                if (window.location.pathname.includes('shop.html')) {
                    if (typeof searchProducts === 'function') {
                        searchProducts(searchTerm);
                    }
                } else {
                    window.location.href = `shop.html?search=${encodeURIComponent(searchTerm)}`;
                }
                
                searchOverlay.style.display = 'none';
                document.body.style.overflow = 'auto';
                searchInput.value = '';
            }
        });
    }
}

// Add loading animation for images (placeholder)
document.querySelectorAll('.placeholder-image').forEach(placeholder => {
    placeholder.addEventListener('click', () => {
        // Simulate image loading
        placeholder.style.opacity = '0.5';
        setTimeout(() => {
            placeholder.style.opacity = '1';
        }, 500);
    });
});

// Form validation helper (for future use)
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Local storage helper functions
function saveToLocalStorage(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
        console.error('Error saving to localStorage:', error);
    }
}

function getFromLocalStorage(key) {
    try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : null;
    } catch (error) {
        console.error('Error reading from localStorage:', error);
        return null;
    }
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    // Load saved cart and wishlist counts
    const savedCartCount = getFromLocalStorage('cartCount');
    const savedWishlistCount = getFromLocalStorage('wishlistCount');
    
    if (savedCartCount !== null) {
        cartCount = savedCartCount;
        updateCartCounter();
    }
    
    if (savedWishlistCount !== null) {
        wishlistCount = savedWishlistCount;
        updateWishlistCounter();
    }
    
    // Add smooth reveal animation to hero section
    const heroContent = document.querySelector('.hero-content');
    const heroImage = document.querySelector('.hero-image');
    
    setTimeout(() => {
        heroContent.style.opacity = '1';
        heroContent.style.transform = 'translateX(0)';
        heroImage.style.opacity = '1';
        heroImage.style.transform = 'translateX(0)';
    }, 300);
    
    // Set initial styles for hero animation
    heroContent.style.opacity = '0';
    heroContent.style.transform = 'translateX(-50px)';
    heroContent.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
    
    heroImage.style.opacity = '0';
    heroImage.style.transform = 'translateX(50px)';
    heroImage.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
    
    // Setup social media links
    setupSocialMediaLinks();
});

// Setup social media functionality
function setupSocialMediaLinks() {
    const socialLinks = document.querySelectorAll('.social-links a, .social-link');
    
    socialLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            // If it's the Facebook link, let it work normally
            if (link.href && link.href.includes('facebook.com')) {
                console.log('Facebook page opened');
                return;
            }
            
            // For placeholder links
            if (link.href === '#' || link.href === '' || !link.href) {
                e.preventDefault();
                const platform = link.querySelector('i').className.includes('instagram') ? 'Instagram' :
                               link.querySelector('i').className.includes('whatsapp') ? 'WhatsApp' :
                               link.querySelector('i').className.includes('youtube') ? 'YouTube' : 'Social Media';
                alert(`${platform} পেজ শীঘ্রই চালু হবে।`);
            }
        });
    });
}
