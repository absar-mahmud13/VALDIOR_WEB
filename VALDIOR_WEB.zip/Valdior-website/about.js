// About Page JavaScript Functionality

// Counter animation for statistics
function animateCounters() {
    const counters = document.querySelectorAll('.stat-number');
    
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const increment = target / 100;
        let current = 0;
        
        const updateCounter = () => {
            if (current < target) {
                current += increment;
                counter.textContent = Math.ceil(current);
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target;
            }
        };
        
        updateCounter();
    });
}

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

// Animate elements on scroll
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
            
            // Trigger counter animation when statistics section is visible
            if (entry.target.classList.contains('statistics-section')) {
                animateCounters();
            }
        }
    });
}, observerOptions);

// Timeline animation for manufacturing process
function animateTimeline() {
    const steps = document.querySelectorAll('.process-step');
    
    steps.forEach((step, index) => {
        setTimeout(() => {
            step.style.opacity = '1';
            step.style.transform = 'translateY(0)';
        }, index * 200);
    });
}

// Team member hover effects
function setupTeamHoverEffects() {
    const teamMembers = document.querySelectorAll('.team-member');
    
    teamMembers.forEach(member => {
        const avatar = member.querySelector('.placeholder-avatar');
        const socialLinks = member.querySelector('.social-links');
        
        member.addEventListener('mouseenter', () => {
            avatar.style.transform = 'scale(1.1)';
            socialLinks.style.opacity = '1';
            socialLinks.style.transform = 'translateY(0)';
        });
        
        member.addEventListener('mouseleave', () => {
            avatar.style.transform = 'scale(1)';
            socialLinks.style.opacity = '0.7';
            socialLinks.style.transform = 'translateY(10px)';
        });
    });
}

// Awards section animation
function setupAwardsAnimation() {
    const awards = document.querySelectorAll('.award-item');
    
    awards.forEach((award, index) => {
        award.style.opacity = '0';
        award.style.transform = 'translateY(30px)';
        award.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        
        setTimeout(() => {
            award.style.opacity = '1';
            award.style.transform = 'translateY(0)';
        }, index * 100);
    });
}

// Brand values animation
function setupBrandValuesAnimation() {
    const values = document.querySelectorAll('.value-item');
    
    values.forEach((value, index) => {
        value.style.opacity = '0';
        value.style.transform = 'translateY(30px)';
        value.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        
        setTimeout(() => {
            value.style.opacity = '1';
            value.style.transform = 'translateY(0)';
        }, index * 200);
    });
}

// Smooth scrolling for internal links
function setupSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Parallax effect for hero section
function setupParallaxEffect() {
    const pageHeader = document.querySelector('.page-header');
    
    if (pageHeader) {
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const parallaxSpeed = 0.5;
            pageHeader.style.transform = `translateY(${scrolled * parallaxSpeed}px)`;
        });
    }
}

// Initialize animations when sections come into view
function initializeScrollAnimations() {
    // Elements to animate on scroll
    const animatedElements = document.querySelectorAll(`
        .brand-story-section,
        .mission-vision,
        .team-section,
        .manufacturing-process,
        .awards-section,
        .statistics-section,
        .cta-section
    `);
    
    animatedElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(50px)';
        element.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
        observer.observe(element);
    });
    
    // Special handling for manufacturing process
    const manufacturingSection = document.querySelector('.manufacturing-process');
    if (manufacturingSection) {
        const processSteps = document.querySelectorAll('.process-step');
        processSteps.forEach(step => {
            step.style.opacity = '0';
            step.style.transform = 'translateY(30px)';
            step.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        });
        
        const processObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateTimeline();
                }
            });
        }, observerOptions);
        
        processObserver.observe(manufacturingSection);
    }
}

// Social media link tracking (for analytics)
function setupSocialTracking() {
    const socialLinks = document.querySelectorAll('.social-links a');
    
    socialLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const platform = link.querySelector('i').className.split(' ')[1].replace('fa-', '');
            console.log(`Social media click: ${platform}`);
            // In a real application, you would send this to analytics
        });
    });
}

// Mobile menu handling for about page
function setupMobileNavigation() {
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
        
        // Close menu when clicking on links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });
    }
}

// CTA button tracking
function setupCTATracking() {
    const ctaButtons = document.querySelectorAll('.cta-btn');
    
    ctaButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const buttonText = button.textContent.trim();
            const buttonType = button.classList.contains('primary') ? 'primary' : 'secondary';
            console.log(`CTA clicked: ${buttonText} (${buttonType})`);
            // In a real application, you would send this to analytics
        });
    });
}

// Page loading animation
function setupPageLoadAnimation() {
    const pageHeader = document.querySelector('.page-header');
    const brandStory = document.querySelector('.brand-story-section');
    
    if (pageHeader) {
        pageHeader.style.opacity = '0';
        pageHeader.style.transform = 'translateY(-50px)';
        pageHeader.style.transition = 'opacity 1s ease, transform 1s ease';
        
        setTimeout(() => {
            pageHeader.style.opacity = '1';
            pageHeader.style.transform = 'translateY(0)';
        }, 300);
    }
}

// Initialize all functionality when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    setupPageLoadAnimation();
    initializeScrollAnimations();
    setupTeamHoverEffects();
    setupSmoothScrolling();
    setupParallaxEffect();
    setupSocialTracking();
    setupMobileNavigation();
    setupCTATracking();
    
    // Delay some animations for better performance
    setTimeout(() => {
        setupBrandValuesAnimation();
        setupAwardsAnimation();
    }, 1000);
});

// Handle window resize for responsive adjustments
window.addEventListener('resize', () => {
    // Recalculate animations if needed
    const isMobile = window.innerWidth <= 768;
    
    if (isMobile) {
        // Disable parallax on mobile for better performance
        const pageHeader = document.querySelector('.page-header');
        if (pageHeader) {
            pageHeader.style.transform = 'none';
        }
    }
});

// Lazy loading for better performance
function setupLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

// Initialize lazy loading
document.addEventListener('DOMContentLoaded', setupLazyLoading);

// Export functions for use in other scripts if needed
window.aboutPageFunctions = {
    animateCounters,
    setupTeamHoverEffects,
    setupBrandValuesAnimation,
    setupAwardsAnimation
};
