// Order Page JavaScript

let currentProductData = null;
let baseDeliveryCharge = 120;

document.addEventListener('DOMContentLoaded', function() {
    initializeOrderPage();
    setupEventListeners();
    loadProductFromURL();
});

function initializeOrderPage() {
    // Set up cart counter
    updateCartCounter();
    
    // Set up navigation
    setupMobileNavigation();
    
    // Set up search functionality
    setupSearchFunctionality();
}

function setupEventListeners() {
    // Quantity controls
    const minusBtn = document.querySelector('.qty-btn.minus');
    const plusBtn = document.querySelector('.qty-btn.plus');
    const quantityInput = document.getElementById('quantity');
    
    if (minusBtn) {
        minusBtn.addEventListener('click', () => updateQuantity(-1));
    }
    
    if (plusBtn) {
        plusBtn.addEventListener('click', () => updateQuantity(1));
    }
    
    if (quantityInput) {
        quantityInput.addEventListener('change', calculateTotal);
    }
    
    // Size selection
    const sizeInputs = document.querySelectorAll('input[name="size"]');
    sizeInputs.forEach(input => {
        input.addEventListener('change', updateProductOptions);
    });
    
    // Payment method selection
    const paymentInputs = document.querySelectorAll('input[name="payment"]');
    paymentInputs.forEach(input => {
        input.addEventListener('change', updatePaymentMethod);
    });
    
    // Form submission
    const orderForm = document.getElementById('order-form');
    if (orderForm) {
        orderForm.addEventListener('submit', handleOrderSubmission);
    }
    
    // City selection for delivery charge
    const citySelect = document.getElementById('customer-city');
    if (citySelect) {
        citySelect.addEventListener('change', updateDeliveryCharge);
    }
}

function loadProductFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    const productData = urlParams.get('product');
    
    if (productData) {
        try {
            currentProductData = JSON.parse(decodeURIComponent(productData));
            displayProductDetails(currentProductData);
            calculateTotal();
        } catch (error) {
            console.error('Error parsing product data:', error);
            showNotification('পণ্যের তথ্য লোড করতে সমস্যা হয়েছে', 'error');
            // Redirect back to shop if no valid product data
            setTimeout(() => {
                window.location.href = 'shop.html';
            }, 2000);
        }
    } else {
        showNotification('কোন পণ্য নির্বাচিত নেই', 'error');
        setTimeout(() => {
            window.location.href = 'shop.html';
        }, 2000);
    }
}

function displayProductDetails(product) {
    // Update product image
    const productImage = document.getElementById('order-product-image');
    if (productImage && product.image) {
        productImage.src = product.image;
        productImage.alt = product.name;
    }
    
    // Update product name
    const productName = document.getElementById('order-product-name');
    if (productName) {
        productName.textContent = product.name;
    }
    
    // Update product description
    const productDescription = document.getElementById('order-product-description');
    if (productDescription) {
        productDescription.textContent = product.description || 'উচ্চ মানের ফ্যাশন পণ্য যা আপনার স্টাইল বাড়াবে।';
    }
    
    // Update product price
    const productPrice = document.getElementById('order-product-price');
    if (productPrice) {
        productPrice.textContent = `৳${product.price.toLocaleString()}`;
    }
    
    // Update original price if there's a discount
    const originalPrice = document.getElementById('order-original-price');
    if (originalPrice && product.originalPrice && product.originalPrice > product.price) {
        originalPrice.textContent = `৳${product.originalPrice.toLocaleString()}`;
        originalPrice.style.display = 'inline';
    }
    
    // Set available sizes
    if (product.sizes && product.sizes.length > 0) {
        updateAvailableSizes(product.sizes);
    }
}

function updateAvailableSizes(availableSizes) {
    const sizeInputs = document.querySelectorAll('input[name="size"]');
    const sizeLabels = document.querySelectorAll('.size-label');
    
    sizeInputs.forEach((input, index) => {
        const size = input.value.toUpperCase();
        const isAvailable = availableSizes.includes(size.toLowerCase()) || availableSizes.includes(size);
        
        input.disabled = !isAvailable;
        sizeLabels[index].style.opacity = isAvailable ? '1' : '0.5';
        sizeLabels[index].style.cursor = isAvailable ? 'pointer' : 'not-allowed';
        
        if (!isAvailable && input.checked) {
            input.checked = false;
            // Select first available size
            const firstAvailable = Array.from(sizeInputs).find(inp => !inp.disabled);
            if (firstAvailable) {
                firstAvailable.checked = true;
            }
        }
    });
}

function updateQuantity(change) {
    const quantityInput = document.getElementById('quantity');
    if (!quantityInput) return;
    
    let currentQuantity = parseInt(quantityInput.value) || 1;
    let newQuantity = currentQuantity + change;
    
    // Ensure quantity is within bounds
    newQuantity = Math.max(1, Math.min(10, newQuantity));
    
    quantityInput.value = newQuantity;
    calculateTotal();
}

function updateProductOptions() {
    // This function can be extended to handle size-specific pricing
    calculateTotal();
}

function updatePaymentMethod() {
    const selectedPayment = document.querySelector('input[name="payment"]:checked');
    if (selectedPayment) {
        console.log('Payment method selected:', selectedPayment.value);
        // You can add payment-specific logic here
        updateDeliveryCharge();
    }
}

function updateDeliveryCharge() {
    const citySelect = document.getElementById('customer-city');
    const deliveryChargeElement = document.getElementById('delivery-charge');
    
    if (!citySelect || !deliveryChargeElement) return;
    
    const selectedCity = citySelect.value;
    let deliveryCharge = baseDeliveryCharge;
    
    // Different delivery charges for different cities
    const deliveryCharges = {
        'dhaka': 120,
        'chittagong': 120,
        'sylhet': 120,
        'rajshahi': 120,
        'khulna': 120,
        'barisal': 120,
        'rangpur': 120,
        'mymensingh': 120,
        'other': 120
    };
    
    if (selectedCity && deliveryCharges[selectedCity]) {
        deliveryCharge = deliveryCharges[selectedCity];
    }
    
    deliveryChargeElement.textContent = `৳${deliveryCharge}`;
    calculateTotal();
}

function calculateTotal() {
    if (!currentProductData) return;
    
    const quantityInput = document.getElementById('quantity');
    const quantity = parseInt(quantityInput?.value) || 1;
    
    const subtotal = currentProductData.price * quantity;
    
    // Get delivery charge
    const deliveryChargeElement = document.getElementById('delivery-charge');
    const deliveryChargeText = deliveryChargeElement?.textContent || '৳120';
    const deliveryCharge = parseInt(deliveryChargeText.replace('৳', '').replace(',', '')) || 120;
    
    const total = subtotal + deliveryCharge;
    
    // Update display
    const subtotalElement = document.getElementById('subtotal-amount');
    const quantityDisplay = document.getElementById('quantity-display');
    const totalElement = document.getElementById('total-amount');
    
    if (subtotalElement) subtotalElement.textContent = `৳${subtotal.toLocaleString()}`;
    if (quantityDisplay) quantityDisplay.textContent = quantity.toString();
    if (totalElement) totalElement.textContent = `৳${total.toLocaleString()}`;
}

function handleOrderSubmission(e) {
    e.preventDefault();
    
    if (!currentProductData) {
        showNotification('পণ্যের তথ্য পাওয়া যায়নি', 'error');
        return;
    }
    
    const submitButton = document.getElementById('place-order-btn');
    if (submitButton) {
        submitButton.classList.add('loading');
        submitButton.textContent = 'অর্ডার প্রক্রিয়াকরণ...';
        submitButton.disabled = true;
    }
    
    // Get form data
    const formData = new FormData(e.target);
    
    // Get selected size and quantity
    const selectedSize = document.querySelector('input[name="size"]:checked')?.value || 'm';
    const quantity = parseInt(document.getElementById('quantity')?.value) || 1;
    const selectedPayment = document.querySelector('input[name="payment"]:checked')?.value || 'cod';
    
    // Calculate totals
    const subtotal = currentProductData.price * quantity;
    const deliveryChargeText = document.getElementById('delivery-charge')?.textContent || '৳120';
    const deliveryCharge = parseInt(deliveryChargeText.replace('৳', '').replace(',', '')) || 120;
    const total = subtotal + deliveryCharge;
    
    // Create order data
    const orderData = {
        // Product info
        product: {
            ...currentProductData,
            selectedSize: selectedSize.toUpperCase(),
            quantity: quantity,
            subtotal: subtotal
        },
        
        // Customer info
        customerName: formData.get('customerName'),
        customerPhone: formData.get('customerPhone'),
        customerEmail: formData.get('customerEmail'),
        customerCity: formData.get('customerCity'),
        
        // Delivery info
        deliveryAddress: formData.get('deliveryAddress'),
        specialInstructions: formData.get('specialInstructions'),
        
        // Payment info
        paymentMethod: selectedPayment,
        deliveryCharge: deliveryCharge,
        total: total,
        
        // Order details
        orderDate: new Date().toISOString(),
        orderId: generateOrderId(),
        status: 'pending'
    };
    
    // Validate required fields
    if (!orderData.customerName || !orderData.customerPhone || !orderData.customerCity || !orderData.deliveryAddress) {
        showNotification('দয়া করে সব প্রয়োজনীয় তথ্য পূরণ করুন!', 'error');
        resetSubmitButton();
        return;
    }
    
    // Validate phone number (basic validation)
    const phoneRegex = /^01[3-9]\d{8}$/;
    if (!phoneRegex.test(orderData.customerPhone.replace(/\s+/g, ''))) {
        showNotification('সঠিক মোবাইল নম্বর দিন (01XXXXXXXXX)', 'error');
        resetSubmitButton();
        return;
    }
    
    // Simulate order processing delay
    setTimeout(() => {
        try {
            // Save order to localStorage
            saveOrder(orderData);
            
            // Show success message
            showSuccessMessage(orderData.orderId);
            
            // Clear form
            e.target.reset();
            
            // Redirect to success page or shop after delay
            setTimeout(() => {
                window.location.href = `shop.html?orderSuccess=${orderData.orderId}`;
            }, 3000);
            
        } catch (error) {
            console.error('Error saving order:', error);
            showNotification('অর্ডার সংরক্ষণে সমস্যা হয়েছে', 'error');
            resetSubmitButton();
        }
    }, 1500);
}

function resetSubmitButton() {
    const submitButton = document.getElementById('place-order-btn');
    if (submitButton) {
        submitButton.classList.remove('loading');
        submitButton.textContent = 'অর্ডার নিশ্চিত করুন';
        submitButton.disabled = false;
    }
}

function generateOrderId() {
    const now = new Date();
    const timestamp = now.getTime().toString().slice(-8);
    const random = Math.floor(Math.random() * 100).toString().padStart(2, '0');
    return `VLD${timestamp}${random}`;
}

function saveOrder(orderData) {
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    orders.push(orderData);
    localStorage.setItem('orders', JSON.stringify(orders));
    console.log('Order saved:', orderData);
}

function showSuccessMessage(orderId) {
    const notification = document.createElement('div');
    notification.className = 'success-notification show';
    notification.innerHTML = `
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <i class="fas fa-check-circle" style="font-size: 1.2rem;"></i>
            <div>
                <div style="font-weight: 600;">অর্ডার সফল হয়েছে!</div>
                <div style="font-size: 0.9rem;">অর্ডার নম্বর: ${orderId}</div>
            </div>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        font-weight: 600;
        z-index: 1000;
        transform: translateX(400px);
        transition: transform 0.3s ease;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    `;
    
    const colors = {
        'success': '#28a745',
        'error': '#dc3545',
        'info': '#17a2b8',
        'warning': '#ffc107'
    };
    
    notification.style.background = colors[type] || colors.info;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Hide notification
    setTimeout(() => {
        notification.style.transform = 'translateX(400px)';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// Helper functions
function updateCartCounter() {
    const cartItems = JSON.parse(localStorage.getItem('cartItems') || '[]');
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
        cartCount.textContent = cartItems.length;
    }
}

function setupMobileNavigation() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
    }
}

function setupSearchFunctionality() {
    const searchInput = document.querySelector('.search-input');
    if (searchInput) {
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const searchTerm = searchInput.value.trim();
                if (searchTerm) {
                    window.location.href = `shop.html?search=${encodeURIComponent(searchTerm)}`;
                }
            }
        });
    }
}
